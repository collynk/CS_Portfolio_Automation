import java.util.HashMap;
import java.util.Map;

public class ContactService {
    // using a HashMap to store contacts with their ID as the key
    private Map<String, Contact> contacts = new HashMap<>();

    // Method to add a new contact
    public boolean addContact(Contact contact) {
        // check if a contact with the same ID already exists
        if (contacts.containsKey(contact.getContactId())) {
            return false;  // Duplicate ID not allowed
        }
        // add the contact map
        contacts.put(contact.getContactId(), contact);
        return true;
    }

    // method to delete a contact by ID
    public boolean deleteContact(String contactId) {
        // Remove the contact if it exists, return true if successful
        return contacts.remove(contactId) != null;
    }

    // method to update an existing contact's details
    public boolean updateContact(String contactId, String firstName, String lastName, String phone, String address) {
        // Retrieve the contact to be updated
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            return false;  // Contact not found
        }
        // Update fields if new values are provided
        if (firstName != null && !firstName.isEmpty()) {
            contact.setFirstName(firstName);
        }
        if (lastName != null && !lastName.isEmpty()) {
            contact.setLastName(lastName);
        }
        if (phone != null && !phone.isEmpty()) {
            contact.setPhone(phone);
        }
        if (address != null && !address.isEmpty()) {
            contact.setAddress(address);
        }
        return true;  // Successfully updated
    }

    // retrieve a contact by ID
    public Contact getContact(String contactId) {
        return contacts.get(contactId);
    }
}
