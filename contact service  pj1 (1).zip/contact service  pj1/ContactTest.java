import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    public void testContactCreation() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Elm St");
        assertAll("Contact creation",
            () -> assertEquals("1234567890", contact.getContactId()),
            () -> assertEquals("John", contact.getFirstName()),
            () -> assertEquals("Doe", contact.getLastName()),
            () -> assertEquals("1234567890", contact.getPhone()),
            () -> assertEquals("123 Elm St", contact.getAddress())
        );
    }

    @Test
    public void testInvalidContactCreation() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "John", "Doe", "1234567890", "123 Elm St");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "John", "Doe", "1234567890", "123 Elm St"); // Invalid ID length
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", null, "Doe", "1234567890", "123 Elm St");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "John", "Doe", "123456789", "123 Elm St"); // Invalid phone length
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "John", "Doe", "1234567890", null);
        });
    }

    @Test
    public void testUpdateContactFields() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Elm St");
        contact.setFirstName("Jane");
        contact.setLastName("Smith");
        contact.setPhone("0987654321");
        contact.setAddress("456 Oak St");

        assertAll("Contact updates",
            () -> assertEquals("Jane", contact.getFirstName()),
            () -> assertEquals("Smith", contact.getLastName()),
            () -> assertEquals("0987654321", contact.getPhone()),
            () -> assertEquals("456 Oak St", contact.getAddress())
        );
    }
}
